// mylibraries.h

#ifndef MYLIBRARIES_H
#define MYLIBRARIES_H

#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
#include <climits>

#endif // MYLIBRARIES_H